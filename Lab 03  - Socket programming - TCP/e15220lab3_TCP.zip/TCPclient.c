/*Sample TCP client */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

int main(int argc, char**argv){
    int sockfd,n;
    struct sockaddr_in servaddr;
    char banner[] = "request";
    char buffer[1000];
    char fileSize[5000];
    FILE *File;

    if (argc != 2 ){
        printf("usage: ./%s <IP address> \n",argv[0]);
        return -1;
    }

    /* socket to connect */
    sockfd=socket(AF_INET,SOCK_STREAM,0);

    /* IP address information of the server to connect */
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr=inet_addr(argv[1]);
    servaddr.sin_port=htons(32000);

    connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));

    sendto(sockfd,banner,strlen(banner),0, (struct sockaddr *)&servaddr,sizeof(servaddr));

    n=recvfrom(sockfd,fileSize,4,0,NULL,NULL);
    int size = atoi(fileSize);
    buffer[n]=0;
    printf("File size:%d \n",size);
    File = fopen("serverfile.txt", "w");
    
    //Receive parts of the file (1000byte) and append to the file.
    for( int i=0; i<size/1000; i++ ){
        n=recvfrom(sockfd,buffer,1000,0,NULL,NULL);
        buffer[n]=0;
        fprintf(File,"%s", buffer);
    }
    printf("File Received\n");
    fclose(File);
    
    return 0 ;
}
