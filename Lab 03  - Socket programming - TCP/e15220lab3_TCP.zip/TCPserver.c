/* Sample TCP server */
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char**argv){
    int listenfd,connfd,n;
    struct sockaddr_in servaddr,cliaddr;
    socklen_t clilen;
    char* banner = "Hello TCP client! This is server";
    char* error = "Request Failed";    
    char buffer[1000];
    char* fileSize = "5000";
    int size = atoi(fileSize);

    char* file = "The rabbit-hole went straight on like a tunnel for some way and then dipped suddenly down, so suddenly that Alice had not a moment to think about stopping herself before she found herself falling down what seemed to be a very deep well. Either the well was very deep, or she fell very slowly, for she had plenty of time, as she went down, to look about her. First, she tried to make out what she was coming to, but it was too dark to see anything; then she looked at the sides of the well and noticed that they were filled with cupboards and book-shelves; here and there she saw maps and pictures hung upon pegs. She took down a jar from one of the shelves as she passed. It was labeled ""ORANGE MARMALADE,"" but, to her great disappointment, it was empty; she did not like to drop the jar, so managed to put it into one of the cupboards as she fell past it.Down, down, down! Would the fall never come to an end? There was nothing else to do, so Alice soon began talking to herself.""Dinah'll miss me very much to-night, I should think!" "(Dinah was the cat.) ""I hope they'll remember her saucer of milk at tea-time. Dinah, my dear, I wish you were down here with me!" "Alice felt that she was dozing off, when suddenly, thump! thump! down she came upon a heap of sticks and dry leaves, and the fall was over.";

    /* one socket is dedicated to listening */
    listenfd=socket(AF_INET,SOCK_STREAM,0);
    
    /* initialize a sockaddr_in struct with our own address information for binding the socket */
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
    servaddr.sin_port=htons(32000);
    
    /* binding */
    bind(listenfd,(struct sockaddr *)&servaddr,sizeof(servaddr));
    
    while(1){
        listen(listenfd,0);
        clilen=sizeof(cliaddr);
        
        /* accept the client with a different socket. */
        connfd = accept(listenfd,(struct sockaddr *) &cliaddr, &clilen); // the uninitialized cliaddr variable is filled in with the
        n = recvfrom(connfd,buffer,1000,0,(struct sockaddr *)&cliaddr,&clilen);// information of the client by recvfrom function
        buffer[n] = 0;

        if( strcmp(buffer,"request")==0 ){

            //Assumed that the file is being read,and 1000 byte is taken to the string variable
            //Send the 1000byte string, here same string is sent repetedly without reading the file
            //And file size is assumed to be 5000bytes. So same 10000byte string is send 5 times.
            sendto(connfd,fileSize,strlen(fileSize),0,(struct sockaddr *)&cliaddr,sizeof(cliaddr));
            
            for(int i=0;i<size/1000;i++){
                sendto(connfd,file,strlen(file),0,(struct sockaddr *)&cliaddr,sizeof(cliaddr));
            }
            printf("File sent successful\n");
        }else{
            sendto(connfd,error,strlen(error),0,(struct sockaddr *)&cliaddr,sizeof(cliaddr));
            printf("%s \n", error);
        }
    }
    return 0;
}
